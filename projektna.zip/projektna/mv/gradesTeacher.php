<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grades ~ Teacher</title>
    <link rel="icon" type="image/x-icon" href="/media/logo.png">
    <link rel="stylesheet" href="styles/gradesTeacher.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
</head>
<body>
    <div class="container">
        <aside>
            <div class="heading">
                <h3>Octopussy classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li onclick="window.location='homeTeacher.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li onclick="window.location='tasksTeacher.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li class="active" onclick="window.location='gradesTeacher.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logoutTeacher.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main>
            <h1>My grades</h1>
            <h2>Slovenščina</h2>
            <table>
                <tbody>
                    <tr>
                        <th>Student name</th>
                        <th>Grades</th>
                        <th>Final grade</th>
                        <th>last changed</th>
                        <th>Add</th>
                    </tr>
                    <tr>
                        <td>St2</td>
                        <td>444</td>
                        <td>4</td>
                        <td>11.1.1111</td>
                        <td>
                            <form action="server/addGrade.php" method="post">
                                <input type="number" name="grade" min="1" max="5">
                                <label for="final">Final grade:</label><input type="checkbox" name="final">
                                <input type="submit" value="Add grade">
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>St2</td>
                        <td>444</td>
                        <td>4</td>
                        <td>11.1.1111</td>
                        <td>
                            <form action="server/addGrade.php" method="post">
                                <input type="number" name="grade" min="1" max="5">
                                <label for="final">Final grade:</label><input type="checkbox" name="final">
                                <input type="submit" value="Add grade">
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>St2</td>
                        <td>444</td>
                        <td>4</td>
                        <td>11.1.1111</td>
                        <td>
                            <form action="server/addGrade.php" method="post">
                                <input type="number" name="grade" min="1" max="5">
                                <label for="final">Final grade:</label><input type="checkbox" name="final">
                                <input type="submit" value="Add grade">
                            </form>
                        </td>
                    </tr>
                 </tbody>
            </table>
            <h2>Matematika</h2>
            <table>
                <tbody>
                    <tr>
                        <th>Student name</th>
                        <th>Grades</th>
                        <th>Final grade</th>
                        <th>last changed</th>
                        <th>Add</th>
                    </tr>
                    <tr>
                        <td>St2</td>
                        <td>444</td>
                        <td>4</td>
                        <td>11.1.1111</td>
                        <td>
                            <form action="server/addGrade.php" method="post">
                                <input type="number" name="grade" min="1" max="5">
                                <label for="final">Final grade:</label><input type="checkbox" name="final">
                                <input type="submit" value="Add grade">
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>St2</td>
                        <td>444</td>
                        <td>4</td>
                        <td>11.1.1111</td>
                        <td>
                            <form action="server/addGrade.php" method="post">
                                <input type="number" name="grade" min="1" max="5">
                                <label for="final">Final grade:</label><input type="checkbox" name="final">
                                <input type="submit" value="Add grade">
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>St2</td>
                        <td>444</td>
                        <td>4</td>
                        <td>11.1.1111</td>
                        <td>
                            <form action="server/addGrade.php" method="post">
                                <input type="number" name="grade" min="1" max="5">
                                <label for="final">Final grade:</label><input type="checkbox" name="final">
                                <input type="submit" value="Add grade">
                            </form>
                        </td>
                    </tr>
                 </tbody>
            </table>
        </main>
    </div>
    <footer>
        <img src="media/logo.png" alt="logo">
        <p>Marko Vošner &copy; | 2022</p>
    </footer>
</body>
</html>
<?php
echo '<div class="subject" data-aos="fade-up" data-aos-delay="200" onclick="window.location=\'subjectTeacher.php?subjectId='.$subjectId.'\'"> <img class="sidebar-icon" src="media/'.$abbr.'.jpg" alt="profile"> <span>'.$subjectName." ".$year.'</span> </div>';
?>
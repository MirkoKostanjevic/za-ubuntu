<?php
include 'server/studentSession.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks ~ Student</title>
    <link rel="icon" type="image/x-icon" href="media/logo.png">
    <link rel="stylesheet" href="styles/tasksStudent.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>
<body>
    <div class="container">
        <aside data-aos="fade-right">
            <div class="heading">
                <h3>Octopussy classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li onclick="window.location='homeStudent.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li onclick="window.location='subjectsStudent.php'">
                        <span>Subjects</span>
                        <img class="sidebar-icon" src="media/subjects.png" alt="profile">
                    </li>
                    <li class="active" onclick="window.location='tasksStudent.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li onclick="window.location='gradesStudent.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logout.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main data-aos="fade-in" data-aos-delay="500" data-aos-duration="2000">
            <h1>My subjects</h1>
            <section class="subjects">
            <?php
                    $sqlCheckSubjects = "select * from viewstudentsinsubjects where studentId = '$studentId'";
                    $resultCheckSubjects = mysqli_query($conn, $sqlCheckSubjects);
                    $rowCheckSubjects = mysqli_fetch_array($resultCheckSubjects);
                    if($rowCheckSubjects == null){
                        echo "<p>No classes</p>";
                    }else{
                        $sqlGetSubjects = "select * from viewstudentsinsubjects where studentId = '$studentId'";
                        $resultGetSubjects = mysqli_query($conn, $sqlGetSubjects);
                        while($rowGetSubjects = mysqli_fetch_array($resultGetSubjects)){
                            $abbr = $rowGetSubjects['abbr'];
                            $subjectName = $rowGetSubjects['subjectName'];
                            $subjectId = $rowGetSubjects['subjectId'];
                            echo '<h2>'.$subjectName.'</h2> <table> <tbody> <tr> <th>Task</th> <th>Date added</th> <th>Date finished</th> <th>Submit</th> </tr>';

                            $sqlViewTasks = "select * from viewalltasksfromstudent where subjectId = '$subjectId'";
                            $resultViewTasks = mysqli_query($conn, $sqlViewTasks);
                            if(mysqli_num_rows($resultViewTasks)>=1){
                                while($rowViewTasks = mysqli_fetch_array($resultViewTasks)){

                                    echo '<tr> <td>'.$rowViewTasks['taskName'].'</td> <td>'.$rowViewTasks['taskStartDate'].'</td> <td>'.$rowViewTasks['taskEndDate'].'</td> <td> <form action="post" method="post"> <input type="file" name="" id=""> <input type="submit" value="Submit task"> </form> </td> </tr>';
                                }
                            }else{
                                echo "<tr><td>No tasks</td></tr>";
                            }
                            echo "</tbody></table>";
                        }
                    }
                ?>
                    
                    
            </section>
        </main>
    </div>
    <?php 
        include 'parts/footer.html';
        include 'aos/aosSetting.html';
    ?>
</body>
</html>
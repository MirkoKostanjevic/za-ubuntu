<?php
include 'server/studentSession.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grades ~ Student</title>
    <link rel="icon" type="image/x-icon" href="media/logo.png">
    <link rel="stylesheet" href="styles/gradesStudent.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>
<body>
    <div class="container">
        <aside data-aos="fade-right">
            <div class="heading">
                <h3>Octopussy classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li onclick="window.location='homeStudent.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li onclick="window.location='subjectsStudent.php'">
                        <span>Subjects</span>
                        <img class="sidebar-icon" src="media/subjects.png" alt="profile">
                    </li>
                    <li onclick="window.location='tasksStudent.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li class="active" onclick="window.location='gradesStudent.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logout.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main data-aos="fade-in">
           <h1>My grades</h1>
           <table>
            <tbody>
                <tr>
                    <th>Subject</th>
                    <th>Grades</th>
                    <th>Final grade</th>
                    <th>last changed</th>
                </tr>
                <?php
                $sqlCheckUserSubjects = "select * from viewstudentsinsubjects where token = '$studentToken'";
                $resultCheckUserSubjects = mysqli_query($conn, $sqlCheckUserSubjects);
                $rowCheckUserSubjects = mysqli_fetch_array($resultCheckUserSubjects);
                if($rowCheckUserSubjects == null){
                    echo "<a href='vsiPredmeti.php'>You are not enrolled in any subject</a>";
                }else{
                    $sqlGetUserSubjects = "select * from viewstudentsinsubjects where token = '$studentToken'";
                    $resultGetUserSubjects = mysqli_query($conn, $sqlGetUserSubjects);
                    while($rowGetUserSubjects = mysqli_fetch_array($resultGetUserSubjects)){
                        $abbr = strtolower($rowGetUserSubjects['abbr']);
                        $subjectName = $rowGetUserSubjects['subjectName'];
                        $subjectId = $rowGetUserSubjects['subjectId'];
                        $year = $rowGetUserSubjects['year'];
                        echo '<tr><td>'.$subjectName.'</td><td>';

                        $sqlGetGrades = "select * from grades where subjectId = '$subjectId' and studentId = '$studentId'";
                        $resultGetGrades = mysqli_query($conn, $sqlGetGrades);
                        if(mysqli_num_rows($resultGetGrades)>=1){
                            while($rowGetGrades = mysqli_fetch_array($resultGetGrades)){
                                $grade = $rowGetGrades['grade'];
                                if ($grade == 1) {
                                    echo "<span style=\"color:red\">".$grade."</span> ";
                                }else{
                                    echo $grade." ";
                                }
                                
                            }
                            echo '</td><td>5</td><td>1.1.1111</td></tr>';
                        }else{
                            echo "No grades";
                        }
                    }
                }
                ?>
             </tbody>
           </table>
        </main>
    </div>
    <?php 
        include 'parts/footer.html';
        include 'aos/aosSetting.html';
    ?>
</body>
</html>
<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['adminToken'])) {
  header("Location: ../index.php");
}
$token = $_SESSION['adminToken'];

$cypherMethod = 'AES-256-CBC';
$key = "markoVosner27";
$iv = '1234567891011121';

$subjectName = $_POST['subjectName'];
$abbr = $_POST['abbr'];
$year = $_POST['year'];

$subjectName = mysqli_real_escape_string($conn, $subjectName);
$abbr = mysqli_real_escape_string($conn, $abbr);
$year = mysqli_real_escape_string($conn, $year);

$sqlGetEmail = "select * from subjects where subjectName = '$subjectName' and year = '$year'";
$resultGetEmail = mysqli_query($conn, $sqlGetEmail);
if(mysqli_num_rows($resultGetEmail)>=1){
    exit("Subject exists");
}else{
    $password = password_hash($password, PASSWORD_DEFAULT);
    $sqlInsertData = "insert into subjects (subjectName, abbr, year) values ('$subjectName', '$abbr', '$year')";
    mysqli_query($conn, $sqlInsertData);
    header('Location: ../admin.php');
    }

?>
<?php
include 'conn.php';

$cypherMethod = 'AES-256-CBC';
$key = "markoVosner27";
$iv = '1234567891011121';

$username = $_POST['username'];
$password = $_POST['password'];

$username = mysqli_real_escape_string($conn, $username);
$password = mysqli_real_escape_string($conn, $password);

$sqlGetEmail = "select * from teachers where username = '$username'";
$resultGetEmail = mysqli_query($conn, $sqlGetEmail);
if(!mysqli_num_rows($resultGetEmail)>=1){
    exit("User nonexistent");
}else{
    $rowGetEmail = mysqli_fetch_array($resultGetEmail);
    $dbpass = $rowGetEmail['password'];
    if(password_verify($password, $dbpass)){
        $userId = $row['userId'];
        $time = time();
        $tokenId = $userId . $time;
        $token = openssl_encrypt($tokenId, $cypherMethod, $key, $options=0, $iv);
        $sql = "UPDATE teachers SET token = '$token' WHERE username = '$username'";
        mysqli_query($conn, $sql);
        session_start();
        $_SESSION['teacherToken'] = $token;
        header("location: ../homeTeacher.php");
    }else{
        exit("Password incorrect");
    }
}
?>
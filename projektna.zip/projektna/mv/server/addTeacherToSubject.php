<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['adminToken'])) {
  header("Location: ../index.php");
}
$token = $_SESSION['adminToken'];

$teacherId = $_POST['teacherId'];
$subjectId = $_POST['subjectId'];

$teacherId = mysqli_real_escape_string($conn, $teacherId);
$subjectId = mysqli_real_escape_string($conn, $subjectId);

    $sqlDeleteData = "DELETE FROM teachers_subjects WHERE subjectId = '$subjectId'";
    mysqli_query($conn, $sqlDeleteData);

    $sqlInsertData = "insert into teachers_subjects (teacherId, subjectId) values ('$teacherId', '$subjectId')";
    mysqli_query($conn, $sqlInsertData);
    header('Location: ../admin.php');

?>
<?php
include 'conn.php';

$token = $_POST['token'];
$teacherId = $_POST['teacherId'];

$sqlValidateAdmin = "select * from admin where token = '$token'";
$resultValidateAdmin = mysqli_query($conn, $sqlValidateAdmin);
if(!mysqli_num_rows($resultValidateAdmin)>=1){
    exit("Wrong token");
}else{
    if ($_POST['key'] == "not") {
        $sqlGetUserData = "SELECT * FROM subjects WHERE subjectId not in(SELECT subjectId from teachers_subjects where teacherId = '$teacherId')";
        $resultGetUserData = mysqli_query($conn, $sqlGetUserData);
        $results = array();
        foreach($resultGetUserData as $row)
        {
            $subjectId = $row['subjectId'];
            $subjectName = $row['subjectName'];

            $results[] = array("subjectId" => $subjectId, "subjectName" => $subjectName);
        }

        exit(json_encode($results));
    } elseif ($_POST['key'] == "is") {
        $sqlGetUserData = "SELECT * FROM subjects WHERE subjectId in(SELECT subjectId from teachers_subjects where teacherId = '$teacherId')";
        $resultGetUserData = mysqli_query($conn, $sqlGetUserData);
        $results = array();
        foreach($resultGetUserData as $row)
        {
            $subjectId = $row['subjectId'];
            $subjectName = $row['subjectName'];

            $results[] = array("subjectId" => $subjectId, "subjectName" => $subjectName);
        }

        exit(json_encode($results));
    }

}
?>
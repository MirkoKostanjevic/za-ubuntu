<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['adminToken'])) {
  header("Location: ../index.php");
}
$token = $_SESSION['adminToken'];

$studentId = $_POST['studentId'];
$subjectId = $_POST['subjectId'];

$studentId = mysqli_real_escape_string($conn, $studentId);
$subjectId = mysqli_real_escape_string($conn, $subjectId);

    $sqlInsertData = "insert into students_subjects (studentId, subjectId) values ('$studentId', '$subjectId')";
    mysqli_query($conn, $sqlInsertData);
    header('Location: ../admin.php');

?>

<?php
include 'conn.php';
include 'studentSession.php';


$subjectId = $_GET['subjectId'];


$subjectId = mysqli_real_escape_string($conn, $subjectId);
$studentId = mysqli_real_escape_string($conn, $studentId);

$sqlDeleteData = "DELETE FROM students_subjects WHERE studentId = '$studentId' and subjectId = '$subjectId'";
mysqli_query($conn, $sqlDeleteData);
header("location: ../subjectStudent.php?subjectId=".$subjectId);

?>
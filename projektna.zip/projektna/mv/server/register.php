<?php
include 'conn.php';

$cypherMethod = 'AES-256-CBC';
$key = "markoVosner27";
$iv = '1234567891011121';

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$username = $_POST['username'];
$password = $_POST['password'];

$firstName = mysqli_real_escape_string($conn, $firstName);
$lastName = mysqli_real_escape_string($conn, $lastName);
$username = mysqli_real_escape_string($conn, $username);
$password = mysqli_real_escape_string($conn, $password);

$sqlGetEmail = "select * from students where username = '$username'";
$resultGetEmail = mysqli_query($conn, $sqlGetEmail);
if(mysqli_num_rows($resultGetEmail)>=1){
    exit("User exists");
}else{
    $password = password_hash($password, PASSWORD_DEFAULT);
    $sqlInsertData = "insert into students (firstName, lastName, username, password) values ('$firstName', '$lastName', '$username', '$password')";
    mysqli_query($conn, $sqlInsertData);

    $sqlGetEmailForSession = "select * from students where username = '$username'";
    $resultGetEmailForSession = mysqli_query($conn, $sqlGetEmailForSession);
    $rowGetEmailForSession = mysqli_fetch_array($resultGetEmailForSession);
    $studentId = $rowGetEmailForSession['studentId'];
    $time = time();
    $tokenId = $studentId . $time;
    $token = openssl_encrypt($tokenId, $cypherMethod, $key, $options=0, $iv);
    $sqlUpdateToken = "UPDATE students SET token = '$token' WHERE studentId = '$studentId'";
    mysqli_query($conn, $sqlUpdateToken);
    echo $_POST['adminCreated'];
    if (isset($_POST['adminCreated'])) {
        $dir = $id;
    if(is_dir($dir) === false ){
        mkdir($dir);
    }
        header("location: ../admin.php");
    }else{
    session_start();
    $_SESSION['studentToken'] = $token;
    $dir = $id;
    if(is_dir($dir) === false ){
        mkdir($dir);
    }
    header('Location: ../homeStudent.php');
    }
    
}
?>
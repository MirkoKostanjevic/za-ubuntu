<?php
include 'conn.php';
include 'studentSession.php';


$subjectId = $_GET['subjectId'];


$subjectId = mysqli_real_escape_string($conn, $subjectId);
$studentId = mysqli_real_escape_string($conn, $studentId);

$sqlInsertData = "insert into students_subjects (studentId, subjectId) values ('$studentId', '$subjectId')";
mysqli_query($conn, $sqlInsertData);
header("location: ../subjectStudent.php?subjectId=".$subjectId);

?>
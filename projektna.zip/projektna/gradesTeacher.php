<!DOCTYPE html>
<html lang="en">
<head>
<?php
    include 'server/teacherSession.php';
    ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grades ~ Teacher</title>
    <link rel="icon" type="image/x-icon" href="/media/logo.png">
    <link rel="stylesheet" href="styles/gradesTeacher.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
</head>
<body>
    <div class="container">
        <aside>
            <div class="heading">
                <h3>Web classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li onclick="window.location='homeTeacher.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li onclick="window.location='tasksTeacher.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li class="active" onclick="window.location='gradesTeacher.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logoutTeacher.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main>
            <h1>My grades</h1>
            <?php
            $sql = "select * from subjects, teachers_subjects where teachers_subjects.teacherId='$teacherId' and teachers_subjects.subjectId = subjects.subjectId";
            $resultGetTasks = mysqli_query($conn, $sql);
            while ($rowGetTask = mysqli_fetch_array($resultGetTasks)) {
                echo "<h2>".$rowGetTask['subjectName']." ".$rowGetTask['year']."</h2> <table> <tbody> <tr> <th>Name</th> <th>Grade</th> <th>Final grade</th> <th>Date updated</th> </tr>";
              $subjectId = $rowGetTask['subjectId'];

              $sqlGetStudentsInSubjects = "select * from students_subjects, students where students_subjects.studentId=students.studentId and students_subjects.subjectId='$subjectId'";
            $resultGetStudentsInSubjects = mysqli_query($conn, $sqlGetStudentsInSubjects);
            while ($rowGetStudentsInSubjects = mysqli_fetch_array($resultGetStudentsInSubjects)) {
                $studentId = $rowGetStudentsInSubjects['studentId'];
                echo "<tr> <td>".$rowGetStudentsInSubjects['firstName']." ".$rowGetStudentsInSubjects['lastName']."</td> <td>";
                $sqlGetGrades = "SELECT * FROM grades WHERE subjectId = '$subjectId' AND studentId = '$studentId';";
                $resultGetGrades = mysqli_query($conn, $sqlGetGrades);
                while ($rowGetGrades = mysqli_fetch_array($resultGetGrades)) {
                    echo $rowGetGrades['grade']." ";
                }
                echo "</td> <td>4</td> <td>11.1.1111</td> <td> <form action=\"server/addGrade.php\" method=\"post\"> <input type=\"number\" name=\"grade\" min=\"1\" max=\"5\"> <label for=\"final\">Final grade:</label><input type=\"checkbox\" name=\"final\"> <input type=\"hidden\" name=\"studentId\" value=\"".$studentId."\"> <input type=\"hidden\" name=\"subjectId\" value=\"".$subjectId."\"> <input type=\"submit\" value=\"Add grade\"> </form> </td> </tr>";
                

            }
            echo '</tbody> </table>';

            }

            ?>
        </main>
    </div>
    <footer>
    <h2>About school</h2>
    <p>The School Center Celje is a Slovenian public education institution based in The Pot na Lavo 22 in Celje. It combines grammar schools, four secondary vocational schools, a higher vocational school and an inter-entrepreneurial education centre. It is one of the largest school centres in Slovenia. &copy; | 2022</p>
    </footer>
</body>
</html>
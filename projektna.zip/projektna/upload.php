<html>
<body>

<?php
$filename = $_FILES['file']['name'];

$location = "uploads/".$filename;

if(move_uploaded_file($_FILES['file']['name'], $location)){
    echo '<p>File uploaded</p>';
}else
{
    echo '<b>File did not upload</b>';
}

?>


</body>
</html>
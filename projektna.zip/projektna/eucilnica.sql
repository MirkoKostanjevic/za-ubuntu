-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gostitelj: 127.0.0.1
-- Čas nastanka: 05. nov 2022 ob 17.56
-- Različica strežnika: 10.4.24-MariaDB
-- Različica PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Zbirka podatkov: `octopussy`
--

-- --------------------------------------------------------

--
-- Struktura tabele `admin`
--

CREATE TABLE `admin` (
  `adminId` int(11) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(100) NOT NULL,
  `token` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `admin`
--

INSERT INTO `admin` (`adminId`, `username`, `password`, `token`) VALUES
(1, 'admin', '$2y$10$tDbqTwoMks0TReq4kGZGG.ypp2kevy8mvVkBcHXUww7z8SKeoZyoi', '674G7BEbXlat6b7Un+uDIXizT3cIGUBPPaO34BcLs2U=');

-- --------------------------------------------------------

--
-- Struktura tabele `grades`
--

CREATE TABLE `grades` (
  `gradeId` int(11) NOT NULL,
  `studentId` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL,
  `grade` int(1) NOT NULL,
  `dateOfGrade` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `grades`
--

INSERT INTO `grades` (`gradeId`, `studentId`, `subjectId`, `grade`, `dateOfGrade`) VALUES
(1, 1, 1, 3, '2022-11-02 23:58:14'),
(2, 1, 1, 5, '2022-11-02 23:58:14');

-- --------------------------------------------------------

--
-- Struktura tabele `students`
--

CREATE TABLE `students` (
  `studentId` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `token` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `students`
--

INSERT INTO `students` (`studentId`, `firstName`, `lastName`, `username`, `password`, `token`) VALUES
(1, 'user', 'name', 'username', '$2y$10$jSq7oo87ATnDkQ/vqmJ92OELwNUHfYi3mV42UM3pjMursBpaMGcQe', 'JNMunu8Dgca7RbY6EzlUhA=='),
(2, 'get', 'passworda', 'forAdmin', 'pass', 'yrf+VipPIjATMTB+Np668Q=='),
(3, 'test', 'aaa', 'testaaa', '$2y$10$O8cNJIlT7nu9atNTdoI.J.eV1qTikYMeMVKhc9uHnFNPih0YYd7g.', '5eCy9VfgpCeilmq+LY+mrQ=='),
(5, 'aass', 'ddd', 'dddd', '$2y$10$N12kWU536oekvUb1365jIOZNXyYjxQqY4UiOi8nIkqHI3HPG0g9na', 'ObY0kfmTfRTkdFKbS99k6Q=='),
(6, 'aass', 'ddd', 'ddddaa', '$2y$10$Kcq42O1Z7pgWHFHgRAB.Gu5GAnlYza/gHu7H//TtsvVUxcgXlA3pW', 'BGDeforX+uPn9VGW1f+/Dg==');

-- --------------------------------------------------------

--
-- Struktura tabele `students_subjects`
--

CREATE TABLE `students_subjects` (
  `connectionId` int(11) NOT NULL,
  `studentId` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `students_subjects`
--

INSERT INTO `students_subjects` (`connectionId`, `studentId`, `subjectId`) VALUES
(1, 1, 1),
(2, 1, 2),
(4, 6, 2),
(5, 0, 4),
(6, 0, 0),
(7, 0, 4),
(8, 0, 4),
(9, 0, 4),
(10, 0, 1),
(11, 1, 4);

-- --------------------------------------------------------

--
-- Struktura tabele `subjects`
--

CREATE TABLE `subjects` (
  `subjectId` int(11) NOT NULL,
  `subjectName` varchar(20) NOT NULL,
  `abbr` varchar(5) NOT NULL,
  `year` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `subjects`
--

INSERT INTO `subjects` (`subjectId`, `subjectName`, `abbr`, `year`) VALUES
(2, 'Slovenščina', 'SLO', 1),
(4, 'test', 'tes', 1),
(6, 'asd', 'dsa', 2);

-- --------------------------------------------------------

--
-- Struktura tabele `tasks`
--

CREATE TABLE `tasks` (
  `taskId` int(11) NOT NULL,
  `taskName` varchar(50) NOT NULL,
  `pathToFile` varchar(100) NOT NULL,
  `subjectId` int(11) NOT NULL,
  `taskStartDate` date NOT NULL,
  `taskEndDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `tasks`
--

INSERT INTO `tasks` (`taskId`, `taskName`, `pathToFile`, `subjectId`, `taskStartDate`, `taskEndDate`) VALUES
(1, 'first task', '', 1, '2022-11-02', '2022-11-09');

-- --------------------------------------------------------

--
-- Struktura tabele `teachers`
--

CREATE TABLE `teachers` (
  `teacherId` int(11) NOT NULL,
  `teacherFirstName` varchar(30) NOT NULL,
  `teacherLastName` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `token` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `teachers`
--

INSERT INTO `teachers` (`teacherId`, `teacherFirstName`, `teacherLastName`, `username`, `password`, `token`) VALUES
(2, 'Ucitelj1', 'Ucitelj2', 'ucitelj', '$2y$10$ay23w6HemxKhXWnrt8OM6e19W4w2DFAmivtiQHPTpY2VmIhY80gAy', ''),
(3, 'teacher2', 'aa', 'aa', '$2y$10$ZmiTPOYgJCQo1g5kdTd/6.4LNWcznVlNRTV7lcHD2jU.0TXbJHSF6', 'a0Lj3NA+Ad/WCSZERh+rBA==');

-- --------------------------------------------------------

--
-- Struktura tabele `teachers_subjects`
--

CREATE TABLE `teachers_subjects` (
  `connectionTSId` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL,
  `teacherId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `teachers_subjects`
--

INSERT INTO `teachers_subjects` (`connectionTSId`, `subjectId`, `teacherId`) VALUES
(6, 2, 2),
(7, 6, 3),
(9, 4, 2);

-- --------------------------------------------------------

--
-- Nadomestna struktura pogleda `viewalltasksfromstudent`
-- (Oglejte si spodaj za resnični pogled)
--
CREATE TABLE `viewalltasksfromstudent` (
`studentId` int(11)
,`firstName` varchar(30)
,`lastName` varchar(30)
,`username` varchar(30)
,`password` varchar(100)
,`token` varchar(50)
,`subjectId` int(11)
,`subjectName` varchar(20)
,`abbr` varchar(5)
,`year` int(1)
,`taskId` int(11)
,`taskName` varchar(50)
,`pathToFile` varchar(100)
,`taskStartDate` date
,`taskEndDate` date
);

-- --------------------------------------------------------

--
-- Nadomestna struktura pogleda `viewstudentsinsubjects`
-- (Oglejte si spodaj za resnični pogled)
--
CREATE TABLE `viewstudentsinsubjects` (
`studentId` int(11)
,`firstName` varchar(30)
,`lastName` varchar(30)
,`username` varchar(30)
,`password` varchar(100)
,`token` varchar(50)
,`subjectId` int(11)
,`subjectName` varchar(20)
,`abbr` varchar(5)
,`year` int(1)
);

-- --------------------------------------------------------

--
-- Nadomestna struktura pogleda `viewteachersinsubjects`
-- (Oglejte si spodaj za resnični pogled)
--
CREATE TABLE `viewteachersinsubjects` (
`teacherId` int(11)
,`teacherFirstName` varchar(30)
,`teacherLastName` varchar(30)
,`username` varchar(30)
,`password` varchar(100)
,`token` varchar(100)
,`subjectId` int(11)
,`subjectName` varchar(20)
,`abbr` varchar(5)
,`year` int(1)
);

-- --------------------------------------------------------

--
-- Struktura pogleda `viewalltasksfromstudent`
--
DROP TABLE IF EXISTS `viewalltasksfromstudent`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewalltasksfromstudent`  AS SELECT `viewstudentsinsubjects`.`studentId` AS `studentId`, `viewstudentsinsubjects`.`firstName` AS `firstName`, `viewstudentsinsubjects`.`lastName` AS `lastName`, `viewstudentsinsubjects`.`username` AS `username`, `viewstudentsinsubjects`.`password` AS `password`, `viewstudentsinsubjects`.`token` AS `token`, `viewstudentsinsubjects`.`subjectId` AS `subjectId`, `viewstudentsinsubjects`.`subjectName` AS `subjectName`, `viewstudentsinsubjects`.`abbr` AS `abbr`, `viewstudentsinsubjects`.`year` AS `year`, `tasks`.`taskId` AS `taskId`, `tasks`.`taskName` AS `taskName`, `tasks`.`pathToFile` AS `pathToFile`, `tasks`.`taskStartDate` AS `taskStartDate`, `tasks`.`taskEndDate` AS `taskEndDate` FROM (`viewstudentsinsubjects` join `tasks` on(`viewstudentsinsubjects`.`subjectId` = `tasks`.`subjectId`))  ;

-- --------------------------------------------------------

--
-- Struktura pogleda `viewstudentsinsubjects`
--
DROP TABLE IF EXISTS `viewstudentsinsubjects`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewstudentsinsubjects`  AS SELECT `students`.`studentId` AS `studentId`, `students`.`firstName` AS `firstName`, `students`.`lastName` AS `lastName`, `students`.`username` AS `username`, `students`.`password` AS `password`, `students`.`token` AS `token`, `subjects`.`subjectId` AS `subjectId`, `subjects`.`subjectName` AS `subjectName`, `subjects`.`abbr` AS `abbr`, `subjects`.`year` AS `year` FROM ((`students` join `students_subjects` on(`students`.`studentId` = `students_subjects`.`studentId`)) join `subjects` on(`students_subjects`.`subjectId` = `subjects`.`subjectId`))  ;

-- --------------------------------------------------------

--
-- Struktura pogleda `viewteachersinsubjects`
--
DROP TABLE IF EXISTS `viewteachersinsubjects`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewteachersinsubjects`  AS SELECT `teachers`.`teacherId` AS `teacherId`, `teachers`.`teacherFirstName` AS `teacherFirstName`, `teachers`.`teacherLastName` AS `teacherLastName`, `teachers`.`username` AS `username`, `teachers`.`password` AS `password`, `teachers`.`token` AS `token`, `subjects`.`subjectId` AS `subjectId`, `subjects`.`subjectName` AS `subjectName`, `subjects`.`abbr` AS `abbr`, `subjects`.`year` AS `year` FROM ((`teachers` join `teachers_subjects` on(`teachers`.`teacherId` = `teachers_subjects`.`teacherId`)) join `subjects` on(`teachers_subjects`.`subjectId` = `subjects`.`subjectId`))  ;

--
-- Indeksi zavrženih tabel
--

--
-- Indeksi tabele `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indeksi tabele `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`gradeId`);

--
-- Indeksi tabele `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentId`);

--
-- Indeksi tabele `students_subjects`
--
ALTER TABLE `students_subjects`
  ADD PRIMARY KEY (`connectionId`);

--
-- Indeksi tabele `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subjectId`);

--
-- Indeksi tabele `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`taskId`);

--
-- Indeksi tabele `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacherId`);

--
-- Indeksi tabele `teachers_subjects`
--
ALTER TABLE `teachers_subjects`
  ADD PRIMARY KEY (`connectionTSId`);

--
-- AUTO_INCREMENT zavrženih tabel
--

--
-- AUTO_INCREMENT tabele `admin`
--
ALTER TABLE `admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT tabele `grades`
--
ALTER TABLE `grades`
  MODIFY `gradeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT tabele `students`
--
ALTER TABLE `students`
  MODIFY `studentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT tabele `students_subjects`
--
ALTER TABLE `students_subjects`
  MODIFY `connectionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT tabele `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subjectId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT tabele `tasks`
--
ALTER TABLE `tasks`
  MODIFY `taskId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT tabele `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacherId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT tabele `teachers_subjects`
--
ALTER TABLE `teachers_subjects`
  MODIFY `connectionTSId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

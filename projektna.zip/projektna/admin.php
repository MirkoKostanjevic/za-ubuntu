<?php
include 'server/adminSession.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="styles/admin.css">
    <link rel="icon" type="image/x-icon" href="media/logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        function showStudents(val){
            if (val == 0) {
                document.getElementById('editStudent').style.display = "none";
            }else{
            document.getElementById('editStudent').style.display = "block";

                $.ajax({
                url: 'server/getStudentData.php',
                method: 'POST',
                dataType: 'JSON',
                data:{
                    studentId: val,
                    token: "<?php echo $token; ?>"}, 
                    success: function(response){
                        console.log(response.lastName);
                        document.getElementById('studentFirstNameEdit').value = response.firstName;
                        document.getElementById('studentLastNameEdit').value = response.lastName;
                        document.getElementById('studentUsernameEdit').value = response.username;
                        document.getElementById('studentId').value = val;
                        
                    }
                })
            }
        }
        function showTeachers(val){
            if (val == 0) {
                document.getElementById('editTeacher').style.display = "none";
            }else{
            document.getElementById('editTeacher').style.display = "block";

                $.ajax({
                url: 'server/getTeacherData.php',
                method: 'POST',
                dataType: 'JSON',
                data:{
                    teacherId: val,
                    token: "<?php echo $token; ?>"}, 
                    success: function(response){
                        console.log(response);
                        document.getElementById('teacherFirstNameEdit').value = response.teacherFirstName;
                        document.getElementById('teacherLastNameEdit').value = response.teacherLastName;
                        document.getElementById('teacherUsernameEdit').value = response.username;
                        document.getElementById('teacherId').value = val;
                        
                    }
                })
            }
        }
        function showSubjects(val){
            if (val == 0) {
                document.getElementById('editSubject').style.display = "none";
            }else{
            document.getElementById('editSubject').style.display = "block";

                $.ajax({
                url: 'server/getSubjectData.php',
                method: 'POST',
                dataType: 'JSON',
                data:{
                    subjectId: val,
                    token: "<?php echo $token; ?>"}, 
                    success: function(response){
                        console.log(response);
                        document.getElementById('subjectNameEdit').value = response.subjectName;
                        document.getElementById('abbrEdit').value = response.abbr;
                        document.getElementById('yearEdit').value = response.year;
                        document.getElementById('subjectId').value = val;
                        
                    }
                })
            }
        }

        function updateStudentSubjectAdd(){

            studentToSubjectAdd = document.getElementById('selectedStudentForSubjectAdd');

            subjectToStudentAdd = document.getElementById('studentSubjectsAdd');
            console.log(subjectToStudentAdd.innerHTML);
            val = studentToSubjectAdd.value;
            console.log(val);
            if (val == 0) {
                subjectToStudentAdd.innerHTML = '<option value="0">Select student first</option>';
            }else{
            str = '';
            $.ajax({
                url: 'server/getSubjectsFromStudents.php',
                method: 'POST',
                dataType: 'JSON',
                data:{
                    key: "not",
                    studentId: val,
                    token: "<?php echo $token; ?>"}, 
                    success: function(response){
                        console.log(response);
                        if (response.length > 0) {
                            for (let index = 0; index < response.length; index++) {
                            str += '<option value="'+response[index].subjectId+'">'+response[index].subjectName+'</option>';                            
                            }
                        }else{
                            str += '<option>Enrolled in all</option>';
                        }
                        subjectToStudentAdd.innerHTML = str;
                    }
                })
            }
        }
        
        function updateStudentSubjectRemove(){

            studentToSubjectAdd = document.getElementById('selectedStudentForSubjectRemove');

            subjectToStudentAdd = document.getElementById('studentSubjectsRemove');
            console.log(subjectToStudentAdd.innerHTML);
            val = studentToSubjectAdd.value;
            console.log(val);
            if (val == 0) {
                subjectToStudentAdd.innerHTML = '<option value="0">Select student first</option>';
            }else{
            str = '';
            $.ajax({
                url: 'server/getSubjectsFromStudents.php',
                method: 'POST',
                dataType: 'JSON',
                data:{
                    key: "is",
                    studentId: val,
                    token: "<?php echo $token; ?>"}, 
                    success: function(response){
                        if (response.length > 0) {
                            for (let index = 0; index < response.length; index++) {
                            str += '<option value="'+response[index].subjectId+'">'+response[index].subjectName+'</option>';                            
                            }
                        }else{
                            str += '<option>Not enrolled</option>';
                        }
                        
                        subjectToStudentAdd.innerHTML = str;
                    }
                })
            }
        }

        function updateTeacherSubjectAdd(){

            teacherToSubjectAdd = document.getElementById('selectedTeacherForSubjectAdd');

            subjectToTeacherAdd = document.getElementById('teacherSubjectsAdd');
            console.log(subjectToTeacherAdd.innerHTML);
            val = teacherToSubjectAdd.value;
            console.log(val);
            if (val == 0) {
                subjectToTeacherAdd.innerHTML = '<option value="0">Select teacher first</option>';
            }else{
            str = '';
            $.ajax({
                url: 'server/getSubjectsFromTeachers.php',
                method: 'POST',
                dataType: 'JSON',
                data:{
                    key: "not",
                    teacherId: val,
                    token: "<?php echo $token; ?>"}, 
                    success: function(response){
                        console.log(response);
                        if (response.length > 0) {
                            for (let index = 0; index < response.length; index++) {
                            str += '<option value="'+response[index].subjectId+'">'+response[index].subjectName+'</option>';                            
                            }
                        }else{
                            str += '<option>Enrolled in all</option>';
                        }
                        subjectToTeacherAdd.innerHTML = str;
                    }
                })
            }
        }
        function updateTeacherSubjectRemove(){

            teacherToSubjectAdd = document.getElementById('selectedTeacherForSubjectRemove');

            subjectToTeacherAdd = document.getElementById('teacherSubjectsRemove');
            console.log(subjectToTeacherAdd.innerHTML);
            val = teacherToSubjectAdd.value;
            console.log(val);
            if (val == 0) {
                subjectToTeacherAdd.innerHTML = '<option value="0">Select teacher first</option>';
            }else{
            str = '';
            $.ajax({
                url: 'server/getSubjectsFromTeachers.php',
                method: 'POST',
                dataType: 'JSON',
                data:{
                    key: "is",
                    teacherId: val,
                    token: "<?php echo $token; ?>"}, 
                    success: function(response){
                        if (response.length > 0) {
                            for (let index = 0; index < response.length; index++) {
                            str += '<option value="'+response[index].subjectId+'">'+response[index].subjectName+'</option>';                            
                            }
                        }else{
                            str += '<option>Not enrolled</option>';
                        }
                        
                        subjectToTeacherAdd.innerHTML = str;
                    }
                })
            }
        }
        
    </script>
</head>
<body>
    <h1>admin</h1>
    <button class="logoutBtn" onclick="window.location='server/logout.php'">Log out</button>
    <section class="students">
        <h2>students</h2>
        <div class="container">
            <div>
                <h3>Add student</h3>
                <form class="addStudent" action="server/register.php" method="post">
                    <input type="hidden" name="adminCreated" value="true">
                    <input type="text" name="firstName" placeholder="First Name...">
                    <input type="text" name="lastName" placeholder="Last Name...">
                    <input type="text" name="username" placeholder="Username...">
                    <input type="password" name="password" placeholder="Password...">
                    <input type="submit" value="Add">
                </form>
            </div>
            <div>
                <h3>Edit student</h3>
                <select name="students" id="students" onchange="showStudents(value)">
                    <option value="0">----</option>
                    <?php
                    $sqlGetStudents = "select * from students";
                    $resultGetStudents = mysqli_query($conn, $sqlGetStudents);
                    while($rowGetStudents = mysqli_fetch_array($resultGetStudents)){
                        echo '<option value="'.$rowGetStudents['studentId'].'">'.$rowGetStudents['username'].'</option>';
                    }
                    ?>

                </select>
                <form id="editStudent" class="editStudent" action="server/editStudentData.php" method="post">
                    <input type="hidden" id="studentId" name="studentId">
                    <input type="text" id="studentFirstNameEdit" name="studentFirstNameEdit" placeholder="First Name...">
                    <input type="text" id="studentLastNameEdit" name="studentLastNameEdit" placeholder="Last Name...">
                    <input type="text" id="studentUsernameEdit" name="studentUsernameEdit" placeholder="Username...">
                    <input type="password" name="studentPasswordEdit" placeholder="Password...">
                    <input type="submit" value="Edit">
                </form>
            </div>
            <div>
                <h3>Remove student</h3>
                <form class="removeStudent" action="server/removeStudent.php" method="post">
                    <select name="rmStudent" id="rmStudent">
                        <option value="0">----</option>
                        <?php
                    $sqlGetStudents = "select * from students";
                    $resultGetStudents = mysqli_query($conn, $sqlGetStudents);
                    while($rowGetStudents = mysqli_fetch_array($resultGetStudents)){
                        echo '<option value="'.$rowGetStudents['studentId'].'">'.$rowGetStudents['username'].'</option>';
                    }
                    ?>
                    </select>
                    <input type="submit" value="Remove">
                </form>
            </div>
        </div>
    </section>
    <section class="students">
        <h2>teachers</h2>
        <div class="container">
            <div>
                <h3>Add teacher</h3>
                <form class="addStudent" action="server/addTeacher.php" method="post">
                    <input type="hidden" name="adminCreated" value="true">
                    <input type="text" name="firstName" placeholder="First Name...">
                    <input type="text" name="lastName" placeholder="Last Name...">
                    <input type="text" name="username" placeholder="Username...">
                    <input type="password" name="password" placeholder="Password...">
                    <input type="submit" value="Add">
                </form>
            </div>
            <div>
                <h3>Edit teacher</h3>
                <select name="teachers" id="teachers" onchange="showTeachers(value)">
                    <option value="0">----</option>
                    <?php
                    $sqlGetStudents = "select * from teachers";
                    $resultGetStudents = mysqli_query($conn, $sqlGetStudents);
                    while($rowGetStudents = mysqli_fetch_array($resultGetStudents)){
                        echo '<option value="'.$rowGetStudents['teacherId'].'">'.$rowGetStudents['username'].'</option>';
                    }
                    ?>
                </select>
                <form id="editTeacher" class="editStudent" action="server/editTeacher.php" method="post">
                    <input type="hidden" id="teacherId" name="teacherId">
                    <input type="text" id="teacherFirstNameEdit" name="teacherFirstNameEdit" placeholder="First Name...">
                    <input type="text" id="teacherLastNameEdit" name="teacherLastNameEdit" placeholder="Last Name...">
                    <input type="text" id="teacherUsernameEdit" name="teacherUsernameEdit" placeholder="Username...">
                    <input type="password" id="teacherPasswordEdit" name="teacherPasswordEdit" placeholder="Password...">
                    <input type="submit" value="Edit">
                </form>
            </div>
            <div>
                <h3>Remove teacher</h3>
                <form class="removeStudent" action="server/removeTeacher.php" method="post">
                    <select name="rmTeacher" id="rmTeacher">
                        <option value="0">----</option>
                        <?php
                    $sqlGetStudents = "select * from teachers";
                    $resultGetStudents = mysqli_query($conn, $sqlGetStudents);
                    while($rowGetStudents = mysqli_fetch_array($resultGetStudents)){
                        echo '<option value="'.$rowGetStudents['teacherId'].'">'.$rowGetStudents['username'].'</option>';
                    }
                    ?>
                    </select>
                    <input type="submit" value="Remove">
                </form>
            </div>
        </div>
    </section>
    <section class="students">
        <h2>subjects</h2>
        <div class="container">
            <div>
                <h3>Add subject</h3>
                <form class="addStudent" action="server/addSubject.php" method="post">
                    <input type="hidden" name="adminCreated" value="true">
                    <input type="text" name="subjectName" placeholder="Subject Name...">
                    <input type="text" name="abbr" placeholder="Abbreviation..." maxlength="5">
                    <input type="text" name="label" value="Year: " disabled>
                    <input type="number" name="year" min="1" max="4" value="1">
                    <input type="submit" value="Add">
                </form>
            </div>
            <div>
                <h3>Edit subject</h3>
                <select name="subjects" id="subjects" onchange="showSubjects(value)">
                    <option value="0">----</option>
                    <?php
                    $sqlGetStudents = "select * from subjects";
                    $resultGetStudents = mysqli_query($conn, $sqlGetStudents);
                    while($rowGetStudents = mysqli_fetch_array($resultGetStudents)){
                        echo '<option value="'.$rowGetStudents['subjectId'].'">'.$rowGetStudents['subjectName']." ".$rowGetStudents['year'].'</option>';
                    }
                    ?>
                </select>
                <form id="editSubject" class="editStudent" action="server/editSubject.php" method="post">
                    <input type="hidden" id="subjectId" name="subjectId">
                    <input type="text" id="subjectNameEdit" name="subjectNameEdit" placeholder="Subject Name...">
                    <input type="text" id="abbrEdit" name="abbrEdit" placeholder="Abbreviation..." maxlength="5">
                    <input type="text" name="labelEdit" value="Year: " disabled>
                    <input type="number" id="yearEdit" name="yearEdit" min="1" max="4" value="1">
                    <input type="submit" value="Edit">
                </form>
            </div>
            <div>
                <h3>Remove subject</h3>
                <form class="removeStudent" action="server/removeSubject.php" method="post">
                    <select name="rmSubject" id="rmSubject">
                        <option value="0">----</option>
                        <?php
                    $sqlGetStudents = "select * from subjects";
                    $resultGetStudents = mysqli_query($conn, $sqlGetStudents);
                    while($rowGetStudents = mysqli_fetch_array($resultGetStudents)){
                        echo '<option value="'.$rowGetStudents['subjectId'].'">'.$rowGetStudents['subjectName']." ".$rowGetStudents['year'].'</option>';
                    }
                    ?>
                    </select>
                    <input type="submit" value="Remove">
                </form>
            </div>
        </div>
    </section>
    <section class="students">
        <h2>Students in subjects</h2>
        <div class="container">
            <div>
                <h3>Add student to subject</h3>
                <form class="addStudent" action="server/addStudentToSubject.php" method="post">
                    <input type="hidden" name="adminCreated" value="true">
                    <select name="studentId" id="selectedStudentForSubjectAdd" onchange="updateStudentSubjectAdd()">
                    <option value="0">----</option>
                    <?php
                    $sqlGetStudents = "select * from students";
                    $resultGetStudents = mysqli_query($conn, $sqlGetStudents);
                    while($rowGetStudents = mysqli_fetch_array($resultGetStudents)){
                        echo '<option value="'.$rowGetStudents['studentId'].'">'.$rowGetStudents['username'].'</option>';
                    }
                    ?>
                    </select>
                    <select name="subjectId" id="studentSubjectsAdd">
                    <option value="0">Select student first</option>
                    <!--- Javascript inject -->
                    </select>
                    <input type="submit" value="Add">
                </form>
            </div>
            <div>
                <h3>Remove student from subject</h3>
                <form class="addStudent" action="server/removeStudentFromSubject.php" method="post">
                    <input type="hidden" name="adminCreated" value="true">
                    <select name="studentId" id="selectedStudentForSubjectRemove" onchange="updateStudentSubjectRemove()">
                    <option value="0">----</option>
                    <?php
                    $sqlGetStudents = "select * from students";
                    $resultGetStudents = mysqli_query($conn, $sqlGetStudents);
                    while($rowGetStudents = mysqli_fetch_array($resultGetStudents)){
                        echo '<option value="'.$rowGetStudents['studentId'].'">'.$rowGetStudents['username'].'</option>';
                    }
                    ?>
                    </select>
                    <select name="subjectId" id="studentSubjectsRemove">
                    <option value="0">Select student first</option>
                    <!--- Javascript inject -->
                    </select>
                    <input type="submit" value="Remove">
                </form>
            </div>
        </div>
    </section>
    <section class="students">
        <h2>Teachers in subjects</h2>
        <div class="container">
            <div>
                <h3>Add teacher to subject</h3>
                <form class="addTeacher" action="server/addTeacherToSubject.php" method="post">
                    <input type="hidden" name="adminCreated" value="true">
                    <select name="teacherId" id="selectedTeacherForSubjectAdd" onchange="updateTeacherSubjectAdd()">
                    <option value="0">----</option>
                    <?php
                    $sqlGetTeachers = "select * from teachers";
                    $resultGetTeachers = mysqli_query($conn, $sqlGetTeachers);
                    while($rowGetTeachers = mysqli_fetch_array($resultGetTeachers)){
                        echo '<option value="'.$rowGetTeachers['teacherId'].'">'.$rowGetTeachers['username'].'</option>';
                    }
                    ?>
                    </select>
                    <select name="subjectId" id="teacherSubjectsAdd">
                    <option value="0">Select teacher first</option>
                    <!--- Javascript inject -->
                    </select>
                    <input type="submit" value="Add">
                </form>
            </div>
            <div>
                <h3>Remove teacher from subject</h3>
                <form class="addTeacher" action="server/removeTeacherFromSubject.php" method="post">
                    <input type="hidden" name="adminCreated" value="true">
                    <select name="teacherId" id="selectedTeacherForSubjectRemove" onchange="updateTeacherSubjectRemove()">
                    <option value="0">----</option>
                    <?php
                    $sqlGetTeachers = "select * from teachers";
                    $resultGetTeachers = mysqli_query($conn, $sqlGetTeachers);
                    while($rowGetTeachers = mysqli_fetch_array($resultGetTeachers)){
                        echo '<option value="'.$rowGetTeachers['teacherId'].'">'.$rowGetTeachers['username'].'</option>';
                    }
                    ?>
                    </select>
                    <select name="subjectId" id="teacherSubjectsRemove">
                    <option value="0">Select teacher first</option>
                    <!--- Javascript inject -->
                    </select>
                    <input type="submit" value="Remove">
                </form>
            </div>
        </div>
    </section>
</body>
</html>
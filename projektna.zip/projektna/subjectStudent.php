<?php
include 'server/studentSession.php';



$subjectId = $_GET['subjectId'];


$sql = "select * from teachers, teachers_subjects where teachers_subjects.subjectId = '$subjectId' and teachers.teacherId = teachers_subjects.teacherId";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);

$isUserEnrolled = false;
$sqlCheckUserEnrollment = "select * from viewstudentsinsubjects where subjectId = '$subjectId' and studentId = '$studentId'";
$resultCheckUserEnrollment = mysqli_query($conn, $sqlCheckUserEnrollment);
if(mysqli_num_rows($resultCheckUserEnrollment)>=1){
    $isUserEnrolled = true;
}

$sqlGetSubjectData = "select * from subjects where subjectId = '$subjectId'";
$resultGetSubjectData = mysqli_query($conn, $sqlGetSubjectData);
$rowGetSubjectData = mysqli_fetch_array($resultGetSubjectData);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $rowGetSubjectData['subjectName']; ?> ~ Student</title>
    <link rel="icon" type="image/x-icon" href="media/logo.png">
    <link rel="stylesheet" href="styles/subjectStudent.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>
<body>
    <div class="container">
        <aside data-aos="fade-right">
            <div class="heading">
                <h3>Octopussy classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li onclick="window.location='homeStudent.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li class="active" onclick="window.location='subjectsStudent.php'">
                        <span>Subjects</span>
                        <img class="sidebar-icon" src="media/subjects.png" alt="profile">
                    </li>
                    <li onclick="window.location='tasksStudent.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li onclick="window.location='gradesStudent.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logout.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main>
            <section data-aos="fade-in" data-aos-delay="900">
                <h1><?php echo $rowGetSubjectData['subjectName']. " ".$rowGetSubjectData['year']; ?></h1>
                <img src="media/<?php echo $rowGetSubjectData['abbr']; ?>.jpg" alt="profile">
                <div class="data">
                    <?php      ?>
                    <span><b>Teacher:</b><?php echo $row['teacherFirstName']." ".$row['teacherLastName'] ?></span>
                    <span><b>Avg. grade:</b>0</span>

                    <?php
                    if($isUserEnrolled){
                        echo '<button onclick="window.location=\'server/disenroll.php?subjectId='.$subjectId.'\'">Disenroll</button>';
                    }else{
                        echo '<button onclick="window.location=\'server/enroll.php?subjectId='.$subjectId.'\'">Enroll</button>';
                    }
                    ?>
                </div>
            </section>
            <section class="tasks" data-aos="fade-up">
                <h2>Tasks</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Task</th>
                            <th>Date added</th>
                            <th>Date finished</th>
                            <th>Submit</th>
                        </tr>
                        <?php
                            $sqlViewTasks = "select * from tasks where subjectId = '$subjectId'";
                            $resultViewTasks = mysqli_query($conn, $sqlViewTasks);
                            if(mysqli_num_rows($resultViewTasks)>=1){
                                while($rowViewTasks = mysqli_fetch_array($resultViewTasks)){
                                    echo '<tr> <td>'.$rowViewTasks['taskName'].'</td> <td>'.$rowViewTasks['taskStartDate'].'</td> <td>'.$rowViewTasks['taskEndDate'].'</td> <td> <form action="post" method="post"> <input type="file" name="" id=""> <input type="submit" value="Submit task"> </form> </td> </tr>';
                                }
                            }else{
                                echo "<tr><td>No tasks</td></tr>";
                            }
                            
                        ?>
                        
                     </tbody>
                </table>
            </section>
            <section class="grades" data-aos="fade-up">
                <h2>Grades</h2>
           <table>
            <tbody>
                <tr>
                    <th>Subject</th>
                    <th>Grades</th>
                    <th>Final grade</th>
                    <th>last changed</th>
                </tr>
                <tr>
                    <td><?php echo $rowGetSubjectData['subjectName']; ?></td>
                    <td>
                    <?php 
                        $sqlGetGrades = "select * from grades where subjectId = '$subjectId' and studentId = '$studentId'";
                        $resultGetGrades = mysqli_query($conn, $sqlGetGrades);
                        if(mysqli_num_rows($resultGetGrades)>=1){
                            while($rowGetGrades = mysqli_fetch_array($resultGetGrades)){
                                echo $rowGetGrades['grade'] . " ";
                            }
                        }else{
                            echo "No grades";
                        }
                        
                    ?>
                    </td>
                    <td>5</td>
                    <td>1.1.1111</td>
                </tr>
             </tbody>
           </table>
            </section>
        </main>
    </div>
    <?php 
        include 'parts/footer.html';
        include 'aos/aosSetting.html';
    ?>
</body>
</html>
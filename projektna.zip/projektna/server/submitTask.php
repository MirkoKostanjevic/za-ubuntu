<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['studentToken'])) {
  header("Location: ../index.php");
}

$studentToken = $_SESSION['studentToken'];
echo $studentToken;
$sqlStudentsData = "select * from students where token = '$studentToken'";
$resultStudentsData = mysqli_query($conn, $sqlStudentsData);
$rowStudentsData = mysqli_fetch_array($resultStudentsData);
$studentId = $rowStudentsData['studentId'];

$subjectId = $_POST['taskId'];
echo $subjectId;
$studentId = mysqli_real_escape_string($conn, $studentId);
$subjectId = mysqli_real_escape_string($conn, $subjectId);



$sqlGetEmail = "insert into submitedtasks (studentId, taskId) values ('$studentId', '$subjectId')"; 
$resultGetEmail = mysqli_query($conn, $sqlGetEmail);
header("location: ../tasksStudent.php");
?>